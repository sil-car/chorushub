﻿using System;
using System.Collections.Generic;
using System.IO;
using Chorus.sync;
using Chorus.Utilities;
using NUnit.Framework;
using System.Linq;

namespace Chorus.Tests.UI.Settings
{
	//[TestFixture]
	public class SettingsModelTests
	{
// this is already tested at the lower levelof the hgrepository
//        [Test]
//        public void GetUserName_NameInLocalReop_GetsName()
//        {
//        }

	}
}