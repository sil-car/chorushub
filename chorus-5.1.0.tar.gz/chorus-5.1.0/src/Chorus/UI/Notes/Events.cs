﻿using Chorus.notes;

namespace Chorus.UI.Notes
{
	public class MessageSelectedEvent : Event<Annotation, Message>
	{ }
}